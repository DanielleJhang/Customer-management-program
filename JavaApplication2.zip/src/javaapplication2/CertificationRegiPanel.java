/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package javaapplication2;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

/**
 *
 * @author J.E JHANG
 */
public class CertificationRegiPanel extends javax.swing.JPanel {
    Connection conn = null;
    PreparedStatement pst = null;
    PreparedStatement lst = null;
    PreparedStatement ust = null;   
    PreparedStatement sst = null;
    PreparedStatement userUD = null;    
    ResultSet rs = null;   
    ResultSet RS = null;
    ResultSet userRS = null;    
    public static String EmployeeNM = null;
    public static String PatronFN = " ", PatronLN=" ", PatronMS = " ";    
    public static String dbid = "Select * from Userinformation where UserID=?"; 
    String CCindex = "None";
    String Spl=" ";
    String ACDate = null, EXDate = null;     
    Boolean workindex=false;    
    /**
     * Creates new form ClassRegisterPanel
     */
    public CertificationRegiPanel() {
        initComponents();
        conn = LoginDB.ConnectDB(); 
        try{
        lst=conn.prepareStatement(dbid);         
        lst.setString(1,Login.EmployeeInfoID);        
        rs = lst.executeQuery();             
        if(rs.next())
        {
        EmployeeNM=rs.getString("Firstname")+" "+rs.getString("Lastname");
        RegisterEmployeeNameField.setText(EmployeeNM);            
        }
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null,e);            
        }           
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        CertBasePanel = new javax.swing.JPanel();
        BelayRadioButton = new javax.swing.JRadioButton();
        jLabel1 = new javax.swing.JLabel();
        LeadRadioButton = new javax.swing.JRadioButton();
        jLabel3 = new javax.swing.JLabel();
        AcquisitionDateChooser = new com.toedter.calendar.JDateChooser();
        jLabel4 = new javax.swing.JLabel();
        ExpirationDateChooser = new com.toedter.calendar.JDateChooser();
        PatronNameField = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        InstructorNameField = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        RegisterEmployeeNameField = new javax.swing.JTextField();
        CertifRegiButton = new javax.swing.JButton();
        PatronIDField = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();

        CertBasePanel.setBackground(new java.awt.Color(165, 205, 188));

        buttonGroup1.add(BelayRadioButton);
        BelayRadioButton.setFont(new java.awt.Font("Calibri", 0, 14)); // NOI18N
        BelayRadioButton.setForeground(new java.awt.Color(58, 98, 81));
        BelayRadioButton.setText("Belay");
        BelayRadioButton.setOpaque(false);
        BelayRadioButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BelayRadioButtonActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Calibri", 1, 16)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(58, 98, 81));
        jLabel1.setText("Certification Type");

        buttonGroup1.add(LeadRadioButton);
        LeadRadioButton.setFont(new java.awt.Font("Calibri", 0, 14)); // NOI18N
        LeadRadioButton.setForeground(new java.awt.Color(58, 98, 81));
        LeadRadioButton.setText("Lead");
        LeadRadioButton.setOpaque(false);
        LeadRadioButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LeadRadioButtonActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Calibri", 1, 16)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(58, 98, 81));
        jLabel3.setText("Date of Acquisition");

        AcquisitionDateChooser.setDateFormatString("M. d. yyyy");
        AcquisitionDateChooser.setFont(new java.awt.Font("Calibri", 0, 12)); // NOI18N

        jLabel4.setFont(new java.awt.Font("Calibri", 1, 16)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(58, 98, 81));
        jLabel4.setText("Date of Expiration");

        ExpirationDateChooser.setDateFormatString("M. d. yyyy");
        ExpirationDateChooser.setFont(new java.awt.Font("Calibri", 0, 12)); // NOI18N

        PatronNameField.setEnabled(false);
        PatronNameField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PatronNameFieldActionPerformed(evt);
            }
        });
        PatronNameField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                PatronNameFieldKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                PatronNameFieldKeyTyped(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Calibri", 0, 16)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(58, 98, 81));
        jLabel5.setText("------------------------------ Patron Name");

        jLabel6.setFont(new java.awt.Font("Calibri", 1, 16)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(58, 98, 81));
        jLabel6.setText("Instructor");

        jLabel7.setFont(new java.awt.Font("Calibri", 1, 16)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(58, 98, 81));
        jLabel7.setText("Registering Certification Authorized by");

        RegisterEmployeeNameField.setEnabled(false);

        CertifRegiButton.setBackground(new java.awt.Color(58, 98, 81));
        CertifRegiButton.setFont(new java.awt.Font("Calibri", 0, 18)); // NOI18N
        CertifRegiButton.setForeground(new java.awt.Color(255, 255, 255));
        CertifRegiButton.setText("Submit");
        CertifRegiButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CertifRegiButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout CertBasePanelLayout = new javax.swing.GroupLayout(CertBasePanel);
        CertBasePanel.setLayout(CertBasePanelLayout);
        CertBasePanelLayout.setHorizontalGroup(
            CertBasePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(CertBasePanelLayout.createSequentialGroup()
                .addGap(47, 47, 47)
                .addGroup(CertBasePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(CertBasePanelLayout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(162, 162, 162)
                        .addComponent(BelayRadioButton))
                    .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, CertBasePanelLayout.createSequentialGroup()
                        .addGroup(CertBasePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(CertBasePanelLayout.createSequentialGroup()
                                .addComponent(jLabel3)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(AcquisitionDateChooser, javax.swing.GroupLayout.PREFERRED_SIZE, 226, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(CertBasePanelLayout.createSequentialGroup()
                                .addComponent(jLabel6)
                                .addGap(18, 18, 18)
                                .addComponent(InstructorNameField, javax.swing.GroupLayout.PREFERRED_SIZE, 305, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(18, 18, 18)
                        .addGroup(CertBasePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(CertifRegiButton, javax.swing.GroupLayout.PREFERRED_SIZE, 134, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(CertBasePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jLabel7)
                                .addComponent(jLabel4)))))
                .addGap(18, 18, 18)
                .addGroup(CertBasePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(CertBasePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(PatronNameField)
                        .addComponent(ExpirationDateChooser, javax.swing.GroupLayout.DEFAULT_SIZE, 222, Short.MAX_VALUE)
                        .addComponent(RegisterEmployeeNameField))
                    .addComponent(LeadRadioButton))
                .addGap(47, 47, 47))
        );
        CertBasePanelLayout.setVerticalGroup(
            CertBasePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(CertBasePanelLayout.createSequentialGroup()
                .addGap(50, 50, 50)
                .addGroup(CertBasePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(BelayRadioButton)
                    .addComponent(jLabel1)
                    .addComponent(LeadRadioButton))
                .addGap(33, 33, 33)
                .addGroup(CertBasePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(CertBasePanelLayout.createSequentialGroup()
                        .addGroup(CertBasePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(PatronNameField, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel5))
                        .addGap(30, 30, 30)
                        .addComponent(jLabel4))
                    .addComponent(ExpirationDateChooser, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(AcquisitionDateChooser, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3))
                .addGap(27, 27, 27)
                .addGroup(CertBasePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(InstructorNameField, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6)
                    .addComponent(jLabel7)
                    .addComponent(RegisterEmployeeNameField, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(80, 80, 80)
                .addComponent(CertifRegiButton, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27))
        );

        PatronIDField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                PatronIDFieldKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                PatronIDFieldKeyTyped(evt);
            }
        });

        jLabel8.setBackground(new java.awt.Color(255, 255, 255));
        jLabel8.setFont(new java.awt.Font("Calibri", 0, 14)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 0, 0));
        jLabel8.setText("* For maintaing Certification, if Patron doesn't attend to Climbing wall more than 3 months, the effect of certification is automatically  ");

        jLabel2.setFont(new java.awt.Font("Calibri", 1, 16)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(58, 98, 81));
        jLabel2.setText("Patron ID");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(58, 58, 58)
                .addComponent(jLabel2)
                .addGap(22, 22, 22)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel8)
                    .addComponent(PatronIDField, javax.swing.GroupLayout.PREFERRED_SIZE, 306, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(134, 134, 134))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(CertBasePanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addContainerGap()))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(116, 116, 116)
                        .addComponent(PatronIDField, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(121, 121, 121)
                        .addComponent(jLabel2)))
                .addGap(147, 147, 147)
                .addComponent(jLabel8)
                .addContainerGap(108, Short.MAX_VALUE))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(CertBasePanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addContainerGap()))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void CertifRegiButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CertifRegiButtonActionPerformed

        conn = LoginDB.ConnectDB();       
        ACDate = ((JTextField)AcquisitionDateChooser.getDateEditor().getUiComponent()).getText();
        EXDate = ((JTextField)ExpirationDateChooser.getDateEditor().getUiComponent()).getText();    
        String UserUpdate = "select Userinformation where UserID=? insert into (Certificationinfo)"+"VALUES('"+CCindex+"')";
        if(ACDate.equals("") ||EXDate.equals(""))
        {
            JOptionPane.showMessageDialog(null, "You should choose the specified date");                         
            return;
        }
        else
        {          
        }
        if(CCindex=="Belay")
        {          
        Spl="insert into CertificationInformation ("
        +"UserID,"
        +"FirstName,"
        +"LastName,"
        +"Membership,"
        +"CertifInfo,"
        +"BelayCertifAcquireDate,"
        +"BelayCertifExpireDate,"
        +"BelayCertifAuthorizedBy,"
        +"BelayDBRegisterEmployee)"
        +"VALUES ('"+PatronIDField.getText()
        +"','"+PatronFN
        +"','"+PatronLN
        +"','"+PatronMS                
        +"','"+CCindex
        +"','"+ACDate
        +"','"+EXDate
        +"','"+InstructorNameField.getText()                                    //Have to change to search instructor name after update DB with new employee and instructor table
        +"','"+EmployeeNM
        +"')";
        }
        else if(CCindex=="Lead")
        {
        Spl="insert into CertificationInformation ("
        +"UserID,"
        +"FirstName,"
        +"LastName,"
        +"Membership,"
        +"CertifInfo,"
        +"LeadCertifAcquireDate,"
        +"LeadCertifExpireDate,"
        +"LeadCertifAuthorizedBy,"
        +"LeadDBRegisterEmployee)"
        +"VALUES ('"+PatronIDField.getText()
        +"','"+PatronFN
        +"','"+PatronLN
        +"','"+PatronMS                
        +"','"+CCindex
        +"','"+ACDate
        +"','"+EXDate
        +"','"+InstructorNameField.getText()                                    //Have to change to search instructor name after update DB with new employee and instructor table
        +"','"+EmployeeNM
        +"')";    
        }

        else
        {
            int p = JOptionPane.showConfirmDialog(null, "You should choose the Certification Type to register","Register Certification",JOptionPane.OK_OPTION);
            if(p==0)
            {
            }
             return;
        }

        try{
            ust=conn.prepareStatement(dbid);
            ust.setString(1,PatronIDField.getText());
            rs = ust.executeQuery();
            if(rs.next())
            {
                workindex=true;
            }
            else
            {
                int p = JOptionPane.showConfirmDialog(null, "We do not have the Patron's ID\n Please try again","Register Certificattion", JOptionPane.OK_OPTION);
                if(p==0)
                {
                    PatronIDField.setText("");
                    PatronIDField.requestFocus();
                }
                return;
            }
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null,e);
        }
        
        if(workindex==true)
        {
          try
          {
              pst=conn.prepareStatement(Spl);
              userUD=conn.prepareStatement(UserUpdate);
              userUD.setString(1,PatronIDField.getText());
              pst.executeUpdate();             
              userUD.executeUpdate();              
              JOptionPane.showMessageDialog(null, "Certification registered :D");
              AcquisitionDateChooser.cleanup();
              ExpirationDateChooser.cleanup();                  
              PatronIDField.setText("");
              InstructorNameField.setText("");
              RegisterEmployeeNameField.setText("");                  
              PatronIDField.requestFocus();
           }
           catch(Exception e)
           {
                JOptionPane.showMessageDialog(null,e);
           }        
         }
    }//GEN-LAST:event_CertifRegiButtonActionPerformed

    private void BelayRadioButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BelayRadioButtonActionPerformed
        CCindex="Belay";
    }//GEN-LAST:event_BelayRadioButtonActionPerformed

    private void LeadRadioButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LeadRadioButtonActionPerformed
        CCindex="Lead";
    }//GEN-LAST:event_LeadRadioButtonActionPerformed

    private void PatronIDFieldKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_PatronIDFieldKeyReleased
         conn = LoginDB.ConnectDB();        
        try
        {
        sst=conn.prepareStatement(dbid);         
        sst.setString(1,PatronIDField.getText());         
        RS = sst.executeQuery();             
        if(RS.next())
        {     
            PatronFN = RS.getString("Firstname");
            PatronLN = RS.getString("Lastname");
            PatronMS = RS.getString("Membership");            
            PatronNameField.setText(PatronFN+" "+PatronLN);
        }
        else
        {   
            PatronFN =" ";
            PatronLN =" ";
            PatronMS =" ";            
        }
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, e);
        }      
    }//GEN-LAST:event_PatronIDFieldKeyReleased

    private void PatronIDFieldKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_PatronIDFieldKeyTyped
    PatronNameField.setText("");
    }//GEN-LAST:event_PatronIDFieldKeyTyped

    private void PatronNameFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PatronNameFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_PatronNameFieldActionPerformed

    private void PatronNameFieldKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_PatronNameFieldKeyTyped

    }//GEN-LAST:event_PatronNameFieldKeyTyped

    private void PatronNameFieldKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_PatronNameFieldKeyReleased

    }//GEN-LAST:event_PatronNameFieldKeyReleased


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private com.toedter.calendar.JDateChooser AcquisitionDateChooser;
    private javax.swing.JRadioButton BelayRadioButton;
    private javax.swing.JPanel CertBasePanel;
    private javax.swing.JButton CertifRegiButton;
    private com.toedter.calendar.JDateChooser ExpirationDateChooser;
    private javax.swing.JTextField InstructorNameField;
    private javax.swing.JRadioButton LeadRadioButton;
    private javax.swing.JTextField PatronIDField;
    private javax.swing.JTextField PatronNameField;
    private javax.swing.JTextField RegisterEmployeeNameField;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    // End of variables declaration//GEN-END:variables
}
