/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;

/**
 *
 * @author J.E JHANG
 */
import java.sql.*; 
import javax.swing.*;
public class LoginDB {
    Connection conn = null;
    ResultSet rs = null;
    PreparedStatement pst = null;
    public static Boolean WFindex = false;
    
    public static Connection ConnectDB()
    {
        try{
            String url="jdbc:odbc:manuu" ;
            //Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection conn = DriverManager.getConnection("jdbc:ucanaccess://C:\\Users\\J.E JHANG\\Documents\\NetBeansProjects\\JavaApplication2\\Data\\DataBase\\Climbingwallproject.accdb");
            //JOptionPane.showConfirmDialog(null, "connection establiched");
            return conn;
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null,e);
            return null;
        }
    }
}
